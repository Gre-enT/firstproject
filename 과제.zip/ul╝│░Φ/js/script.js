$(function(){

/////////////////////////// 호버이벤트 정리 ////////////////////////
    $(".gnb>li").mouseover(function(){
        $(this).css("background-color", "skyblue");

        $(this).children(".sub_menu").stop().slideDown(400);
    })
    $(".gnb>li").mouseleave(function(){
        $(this).css("background-color", "")
        $(this).children(".sub_menu").stop().slideUp(400);
    })

    $(".sub_menu>li").mouseover(function(){
        $(this).css("background-color", "rgb(245, 126, 41)");
        $(this).children("a").css("color", "white");
    })
    $(".sub_menu>li").mouseleave(function(){
        $(this).css("background-color", "");
        $(this).children("a").css("color", "");
    })

    $(".top_news").mouseover(function(){
        $(".top_img>img").css({
            "transform":"scale(1.05)",
            "transition-duration":"0.2s"
        })
    })
    $(".top_news").mouseleave(function(){
        $(".top_img>img").css({
            "transform":"",
            "transition-duration":""
        });
    })
//////////////////////////////////////////////////////////////

////////////// 뉴스 탭메뉴 이벤트 - 15초마다 돌아감, 테스트로 5초 ////////////////
    let news_now = 0;

    $.ajax({
        url:"data/subject.json",
        dataType: "json",
        success: function(data){
            console.log(data);
            
            let subList = "<ul class='sub_list'>";

            for(i in data){
                let $subject = data[i].subject;

                subList += "<li>" + $subject + "</li>";

            }
            subList += "</ul>";
            console.log(subList);

            $(".con_right>h2").after(subList);
            $(".sub_list>li").eq(news_now).addClass("on");
        },
        error: function(){
            alert("실패");
        }                
    })

    let sub_move = setInterval(sub_slide, 5000); //테스트로 5초에 한번 회전

    function sub_slide(){
        news_now++;
        if(news_now == $(".sub_list>li").length){
            news_now = 0;
        }
        $(".sub_list>li").css("transition", "background-color 0.5s ease")
        $(".sub_list>li").eq(news_now).addClass("on")
        .siblings(".sub_list>li").removeClass("on");

    }

    $(".sub_list>li").on({
        mouseenter:function(){
            clearInterval(sub_move);
            console.log(this);
        },
        mouseleave:function(){
            sub_move = setInterval(sub_slide, 5000);
            console.log(this);
        },
        click:function(){
            $(this).addClass("on")
            .siblings("li").removeClass("on");
        }
    })

})




